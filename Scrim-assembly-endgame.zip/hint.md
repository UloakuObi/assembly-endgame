You'll need to find a way to know if the most recently-
guessed letter was correct or not, so you're only
displaying the farewell message after wrong guesses.